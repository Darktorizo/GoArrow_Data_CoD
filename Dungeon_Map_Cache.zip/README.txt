Unzip the contents of `Dungeon Maps Cache` directory from this zip file to `C:\Games\VirindiPlugins\GoArrowVVSEdition\Dungeon Map Cache\`

You can (and probably should?) overwrite any existing files.

Example structure:
  C:\Games\VirindiPlugins\GoArrowVVSEdition\Dungeon Map Cache\000A.gif
  C:\Games\VirindiPlugins\GoArrowVVSEdition\Dungeon Map Cache\000B.gif
  C:\Games\VirindiPlugins\GoArrowVVSEdition\Dungeon Map Cache\000C.gif
  ... etc ...